 <script>
      jquery(document).ready(function(){
      $('header').ripples({
  dropRadius: 20,
  perturbance: 0.03,
  
})

        });
    </script>
